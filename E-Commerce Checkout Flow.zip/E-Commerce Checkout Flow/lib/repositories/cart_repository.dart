import 'package:hive_flutter/hive_flutter.dart';
import '../models/cart_item.dart';

class CartRepository {
  static const String _boxName = 'cart_box';

  Future<Box<CartItem>> _getBox() async {
    if (!Hive.isBoxOpen(_boxName)) {
      return await Hive.openBox<CartItem>(_boxName);
    }
    return Hive.box<CartItem>(_boxName);
  }

  Future<List<CartItem>> getCartItems() async {
    final box = await _getBox();
    return box.values.toList();
  }

  Future<void> addItem(CartItem item) async {
    final box = await _getBox();
    await box.put(item.product.id, item);
  }

  Future<void> removeItem(String productId) async {
    final box = await _getBox();
    await box.delete(productId);
  }

  Future<void> updateQuantity(String productId, int quantity) async {
    final box = await _getBox();
    final item = box.get(productId);
    if (item != null) {
      await box.put(productId, item.copyWith(quantity: quantity));
    }
  }

  Future<void> clearCart() async {
    final box = await _getBox();
    await box.clear();
  }
}
