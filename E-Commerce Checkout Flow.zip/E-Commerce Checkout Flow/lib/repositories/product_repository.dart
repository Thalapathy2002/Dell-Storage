import '../models/product.dart';

class ProductRepository {
  Future<List<Product>> getProducts() async {
    // Simulate network delay
    await Future.delayed(const Duration(milliseconds: 1500));
    
    return [
      const Product(
        id: '1',
        title: 'Wireless Headphones',
        description: 'High-quality Bluetooth headphones with noise cancellation',
        price: 99.99,
        imageUrl: 'https://via.placeholder.com/300x300/4A90E2/FFFFFF?text=Headphones',
        rating: 4.5,
        inStock: true,
      ),
      const Product(
        id: '2',
        title: 'Smart Watch',
        description: 'Fitness tracker with heart rate monitor',
        price: 199.99,
        imageUrl: 'https://via.placeholder.com/300x300/E94B3C/FFFFFF?text=Watch',
        rating: 4.7,
        inStock: true,
      ),
      const Product(
        id: '3',
        title: 'Laptop Stand',
        description: 'Ergonomic aluminum laptop stand',
        price: 49.99,
        imageUrl: 'https://via.placeholder.com/300x300/6AB04C/FFFFFF?text=Stand',
        rating: 4.3,
        inStock: true,
      ),
      const Product(
        id: '4',
        title: 'Mechanical Keyboard',
        description: 'RGB backlit gaming keyboard with blue switches',
        price: 129.99,
        imageUrl: 'https://via.placeholder.com/300x300/F39C12/FFFFFF?text=Keyboard',
        rating: 4.8,
        inStock: true,
      ),
      const Product(
        id: '5',
        title: 'USB-C Hub',
        description: '7-in-1 USB-C hub with HDMI and USB 3.0',
        price: 39.99,
        imageUrl: 'https://via.placeholder.com/300x300/9B59B6/FFFFFF?text=Hub',
        rating: 4.2,
        inStock: false,
      ),
      const Product(
        id: '6',
        title: 'Wireless Mouse',
        description: 'Ergonomic wireless mouse with precision tracking',
        price: 29.99,
        imageUrl: 'https://via.placeholder.com/300x300/3498DB/FFFFFF?text=Mouse',
        rating: 4.4,
        inStock: true,
      ),
      const Product(
        id: '7',
        title: 'Portable SSD',
        description: '1TB external solid state drive with USB-C',
        price: 149.99,
        imageUrl: 'https://via.placeholder.com/300x300/E74C3C/FFFFFF?text=SSD',
        rating: 4.6,
        inStock: true,
      ),
      const Product(
        id: '8',
        title: 'Webcam HD',
        description: '1080p webcam with auto-focus',
        price: 79.99,
        imageUrl: 'https://via.placeholder.com/300x300/1ABC9C/FFFFFF?text=Webcam',
        rating: 4.1,
        inStock: true,
      ),
      const Product(
        id: '9',
        title: 'Phone Case',
        description: 'Shockproof protective phone case',
        price: 19.99,
        imageUrl: 'https://via.placeholder.com/300x300/34495E/FFFFFF?text=Case',
        rating: 4.0,
        inStock: true,
      ),
      const Product(
        id: '10',
        title: 'Desk Lamp',
        description: 'LED desk lamp with adjustable brightness',
        price: 34.99,
        imageUrl: 'https://via.placeholder.com/300x300/F1C40F/FFFFFF?text=Lamp',
        rating: 4.5,
        inStock: true,
      ),
      const Product(
        id: '11',
        title: 'Power Bank',
        description: '20000mAh portable charger',
        price: 44.99,
        imageUrl: 'https://via.placeholder.com/300x300/E67E22/FFFFFF?text=PowerBank',
        rating: 4.3,
        inStock: true,
      ),
      const Product(
        id: '12',
        title: 'Screen Protector',
        description: 'Tempered glass screen protector',
        price: 9.99,
        imageUrl: 'https://via.placeholder.com/300x300/95A5A6/FFFFFF?text=Protector',
        rating: 4.2,
        inStock: true,
      ),
    ];
  }

  Future<Product?> getProductById(String id) async {
    final products = await getProducts();
    try {
      return products.firstWhere((product) => product.id == id);
    } catch (e) {
      return null;
    }
  }
}
