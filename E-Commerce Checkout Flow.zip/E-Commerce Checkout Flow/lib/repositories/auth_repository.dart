import '../models/user.dart';

class AuthRepository {
  static const String _mockEmail = 'user@example.com';
  static const String _mockPassword = 'password123';

  Future<User?> login(String email, String password) async {
    // Simulate network delay
    await Future.delayed(const Duration(seconds: 1));

    if (email == _mockEmail && password == _mockPassword) {
      return const User(
        id: 'user_001',
        email: _mockEmail,
        name: 'John Doe',
      );
    }
    return null;
  }

  Future<void> logout() async {
    await Future.delayed(const Duration(milliseconds: 500));
  }
}
