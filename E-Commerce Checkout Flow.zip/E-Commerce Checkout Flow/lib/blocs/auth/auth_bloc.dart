import 'package:ecommerce_bloc_app/models/user.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'auth_event.dart';
import 'auth_state.dart';
import '../../repositories/auth_repository.dart';
import '../../utils/hive_helper.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;

  AuthBloc({required this.authRepository}) : super(AuthInitial()) {
    on<AuthCheckRequested>(_onAuthCheckRequested);
    on<AuthLoginRequested>(_onAuthLoginRequested);
    on<AuthLogoutRequested>(_onAuthLogoutRequested);
    on<AuthGuestMode>(_onAuthGuestMode);
  }

  Future<void> _onAuthCheckRequested(
    AuthCheckRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    final authState = await HiveHelper.getAuthState();
    final isAuthenticated = authState['isAuthenticated'] as bool;
    
    if (isAuthenticated) {
      final email = authState['userEmail'] as String?;
      if (email != null) {
        emit(AuthAuthenticated(const User(
          id: 'user_001',
          email: 'user@example.com',
          name: 'John Doe',
        )));
      } else {
        emit(AuthUnauthenticated());
      }
    } else {
      emit(AuthUnauthenticated());
    }
  }

  Future<void> _onAuthLoginRequested(
    AuthLoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    try {
      final user = await authRepository.login(event.email, event.password);
      
      if (user != null) {
        await HiveHelper.saveAuthState(true, user.email);
        emit(AuthAuthenticated(user));
      } else {
        emit(const AuthError('Invalid email or password'));
      }
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> _onAuthLogoutRequested(
    AuthLogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());
    
    await authRepository.logout();
    await HiveHelper.clearAuthState();
    
    emit(AuthUnauthenticated());
  }

  Future<void> _onAuthGuestMode(
    AuthGuestMode event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthGuest());
  }
}
