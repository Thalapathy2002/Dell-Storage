import 'package:equatable/equatable.dart';
import '../../models/cart_item.dart';

abstract class CartEvent extends Equatable {
  const CartEvent();

  @override
  List<Object?> get props => [];
}

class CartLoadRequested extends CartEvent {}

class CartItemAdded extends CartEvent {
  final CartItem item;

  const CartItemAdded(this.item);

  @override
  List<Object?> get props => [item];
}

class CartItemRemoved extends CartEvent {
  final String productId;

  const CartItemRemoved(this.productId);

  @override
  List<Object?> get props => [productId];
}

class CartItemQuantityUpdated extends CartEvent {
  final String productId;
  final int quantity;

  const CartItemQuantityUpdated(this.productId, this.quantity);

  @override
  List<Object?> get props => [productId, quantity];
}

class CartCleared extends CartEvent {}
