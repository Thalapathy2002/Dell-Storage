import 'package:equatable/equatable.dart';

abstract class ProductEvent extends Equatable {
  const ProductEvent();

  @override
  List<Object?> get props => [];
}

class ProductLoadRequested extends ProductEvent {}

class ProductRefreshRequested extends ProductEvent {}

class ProductDetailRequested extends ProductEvent {
  final String productId;

  const ProductDetailRequested(this.productId);

  @override
  List<Object?> get props => [productId];
}
