import 'package:hive_flutter/hive_flutter.dart';

class HiveHelper {
  static const String authBoxName = 'auth_box';

  static Future<void> init() async {
    await Hive.initFlutter();
    // Note: We'll register adapters after generating them
  }

  static Future<void> saveAuthState(bool isAuthenticated, String? userEmail) async {
    final box = await Hive.openBox(authBoxName);
    await box.put('isAuthenticated', isAuthenticated);
    await box.put('userEmail', userEmail);
  }

  static Future<Map<String, dynamic>> getAuthState() async {
    final box = await Hive.openBox(authBoxName);
    return {
      'isAuthenticated': box.get('isAuthenticated', defaultValue: false),
      'userEmail': box.get('userEmail'),
    };
  }

  static Future<void> clearAuthState() async {
    final box = await Hive.openBox(authBoxName);
    await box.clear();
  }
}
