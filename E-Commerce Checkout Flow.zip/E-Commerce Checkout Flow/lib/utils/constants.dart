import 'package:flutter/material.dart';

class AppConstants {
  // Colors
  static const Color primaryColor = Color(0xFF4A90E2);
  static const Color secondaryColor = Color(0xFFE94B3C);
  static const Color backgroundColor = Color(0xFFF5F5F5);
  
  // Tax rate
  static const double taxRate = 0.05; // 5%
  
  // Padding
  static const double defaultPadding = 16.0;
  static const double smallPadding = 8.0;
  static const double largePadding = 24.0;
}
