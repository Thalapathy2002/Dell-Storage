import 'package:equatable/equatable.dart';

class Order extends Equatable {
  final String orderId;
  final double total;
  final DateTime timestamp;

  const Order({
    required this.orderId,
    required this.total,
    required this.timestamp,
  });

  @override
  List<Object?> get props => [orderId, total, timestamp];
}
