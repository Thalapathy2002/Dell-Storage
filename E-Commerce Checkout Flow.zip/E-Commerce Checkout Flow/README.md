# 🛍️ Flutter E-Commerce App with BLoC Architecture

A complete, production-ready Flutter e-commerce application built with **BLoC state management**, featuring product listing, shopping cart, checkout flow, and user authentication.

## 🚀 **Installation**

### Prerequisites

- Flutter SDK 3.19 or higher
- Dart SDK 3.0 or higher
- Android Studio or Xcode (for emulator)
- Git

### Steps

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd ecommerce_bloc_app
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Generate Hive adapters**
   ```bash
   flutter packages pub run build_runner build --delete-conflicting-outputs
   ```

4. **Run the app**
   ```bash
   flutter run
   ```

---

## ⚙️ **Configuration**

### Dependencies in `pubspec.yaml`

All dependencies are already configured. Key packages:

```yaml
dependencies:
  flutter_bloc: ^8.1.3          # State management
  hive: ^2.2.3                  # Local database
  hive_flutter: ^1.1.0          # Hive Flutter integration
  equatable: ^2.0.5             # Value equality
```

### Environment Variables

Currently, no environment variables are required. All configurations are in `lib/utils/constants.dart`:

```dart
class AppConstants {
  static const Color primaryColor = Color(0xFF4A90E2);
  static const Color secondaryColor = Color(0xFFE94B3C);
  static const double taxRate = 0.05; // 5% tax
}
```

---

## 📖 **Usage**

### First Launch

1. App loads login screen
2. Use demo credentials or continue as guest
3. Browse products on home screen
4. Tap any product for details

### Complete User Journey

```
Login/Guest Mode
    ↓
Browse Products (Home)
    ↓
View Product Details
    ↓
Add to Cart
    ↓
Navigate to Cart Tab
    ↓
Update Quantities or Remove Items
    ↓
Proceed to Checkout
    ↓
Review Cart (Step 1)
    ↓
Fill Shipping Address (Step 2)
    ↓
Review Order Summary (Step 3)
    ↓
Place Order
    ↓
Order Confirmation
```

### Key User Actions

#### **Browsing Products**
- Scroll through grid layout
- Pull-to-refresh to reload products
- Tap product card for details
- View ratings and stock status

#### **Adding to Cart**
- Adjust quantity (1-10)
- Tap "Add to Cart"
- View cart count badge

#### **Cart Management**
- Increase/decrease quantity with +/- buttons
- Swipe or tap delete to remove items
- Auto-calculates subtotal, tax, and total

#### **Checkout**
- Step 1: Review items
- Step 2: Fill shipping details
- Step 3: Confirm order
- Place order → Confirmation

---

## 🔐 **Demo Credentials**

### Login Account

| Field | Value |
|-------|-------|
| Email | `user@example.com` |
| Password | `password123` |

### Guest Mode

- No credentials needed
- Can browse and add to cart
- Must login to checkout

---

## 🏗️ **Project Architecture**

### BLoC Architecture Pattern

```
User Interaction
      ↓
   Screen
      ↓
   Event → BLoC → State
      ↓
Repository (Data Layer)
      ↓
Hive / Mock API
```

### Data Flow

1. **Presentation Layer (Screens)**
   - Displays UI
   - Listens to BLoC states
   - Sends events to BLoC

2. **Business Logic Layer (BLoCs)**
   - Handles events
   - Processes business logic
   - Emits new states

3. **Data Layer (Repositories)**
   - Manages data sources
   - Hive for persistence
   - Mock API calls

### State Management Approach

- **Equatable**: For value equality of states
- **Multi-BLoC Provider**: For dependency injection
- **BlocBuilder**: For UI updates
- **BlocListener**: For one-time events (snackbars, navigation)

---

## 🧪 **Testing**

### Phase-by-Phase Testing

#### Phase 1: Foundation Setup ✅

```bash
flutter pub get
flutter run
```
**Expected:** App launches with basic structure

#### Phase 2: BLoC & Core Screens ✅

```bash
flutter packages pub run build_runner build --delete-conflicting-outputs
flutter run
```
**Expected:** Login works, products display, navigation works

#### Phase 3: Cart & Checkout ✅

```bash
flutter run
```
**Expected:** Complete checkout flow works

### Manual Test Scenarios

1. **Login Test**
   - Enter wrong credentials → Error message
   - Enter correct credentials → Navigate to home
   - Continue as guest → Access without login

2. **Product Browsing**
   - Scroll through products
   - Pull-to-refresh loads products
   - Click product → Details screen opens
   - Out of stock items show disabled state

3. **Cart Operations**
   - Add to cart → Badge updates
   - Increase/decrease quantity
   - Remove items → Cart updates
   - Clear cart → Empty state shows

4. **Checkout Flow**
   - Empty cart → Checkout button disabled
   - Guest user → Redirected to login
   - Fill address form → Validation works
   - Place order → Order ID generated

5. **Persistence**
   - Add to cart → Kill app → Reopen → Cart persists
   - Login → Kill app → Reopen → Still logged in

---

##  **Troubleshooting**

### Common Issues

#### Issue: "MissingPluginException" on app launch

**Solution:**
```bash
flutter clean
flutter pub get
flutter run
```

#### Issue: Hive adapters not generating

**Solution:**
```bash
flutter packages pub run build_runner build --delete-conflicting-outputs
```

#### Issue: App crashes on cart operations

**Solution:**
- Ensure Hive adapters are generated
- Clear app data: `flutter clean`
- Rebuild: `flutter run`

#### Issue: Products not loading

**Solution:**
- Check network connectivity
- Verify `ProductRepository` mock data
- Check BLoC events are firing

#### Issue: Login not working

**Credentials Check:**
- Email: `user@example.com` (exact match)
- Password: `password123` (exact match)
- Ensure no extra spaces

#### Issue: UI not updating after BLoC event

**Solution:**
- Verify BLoC is provided in `main.dart`
- Ensure screen is using `BlocBuilder`
- Check state equality with `Equatable`

---
