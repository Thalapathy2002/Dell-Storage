use anchor_lang::prelude::*;

declare_id!("DF2HuPNTsM6ZD4GhpCwi8zVf2S1mTU8epLxwMKH9rJto");

#[program]
pub mod myanchorproject {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        msg!("Greetings from: {:?}", ctx.program_id);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize {}
